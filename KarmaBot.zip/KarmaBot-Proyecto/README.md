> 💝 Versión Actual: V2

## ❤️‍🔥 **`KarmaBot`**
## 🔥 **`Karma "El Karma de la vida ahora en WhatsApp**
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF0000&lines=Bienvenid@+a+mi+repositorio;disfruta+de+HuTao🦋+❤️‍🔥yajuuu🔥)](https://git.io/typing-svg)
![Karma](https://qu.ax/OOECB.png)

---

### <img src="https://i.pinimg.com/originals/19/80/6e/19806e91932e6054965fc83b85241270.gif" alt="Prueba El Bot Aqui" width="42" height="42"> Prueba El Bot Aqui

> Si Deseas Probar El Bot Antes De Instalarlo, Click Abajo. 🍟

[![Click Aquí](https://img.shields.io/badge/Grupo-Karma-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/EXRMIJJ9q9e40A3mi5Z3uc)

🍟 **`INSTALACION MANUAL POR TERMUX`**

[`🚩 Instalar Termux Clic Aqui`](https://www.mediafire.com/file/pqd980pnrqrz7r3/termux-app_v0.118.1+github-debug_arm64-v8a.apk/file)

> ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:

```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
git clone https://github.com/CheirZ/HuTao-Proyect.git && cd HuTao-Proyect
```
```bash
yarn install && npm update && npm i
```
```bash
npm start
```

🍟 **`ACTIVAR EN TERMUX EN CASO DE DETENERSE`**
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd KarmaBot
> npm start
```

🔥 **`OBTENER OTRO CODIGO QR`**
```bash
> ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd KarmaBot
> rm -rf Seccion-activas
> npm start
```

🍟 **`KarmaBot 24/7 (TERMUX)`**
```bash
> termux-wake-lock && npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs 
```

💥 **`ACTUALIZAR Karma`**
> Note Comandos para actualizar KarmaBot de forma automática
```bash
grep -q 'bash\|wget' <(dpkg -l) || apt install -y bash wget && wget -O - https://raw.githubusercontent.com/CheirZ/HuTao-Proyect/master/update.sh | bash
```
Para que no pierda su progreso en Karma, estos comandos realizarán un respaldo de su `database.json` y se agregará a la versión más reciente.

> Warning Estos comandos solo funcionan para TERMUX, REPLIT, LINUX

---

#### ☂️ ACTIVA EN HEROKU ☂️
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/CheirZ/HuTao-Proyect)

#### Heroku Buildpack
| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[click](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [click](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |

#### 🟢 ACTIVAR EN CODES SPACES 
[`CREAR SERVIDOR`](https://github.com/codespaces/new?skip_quickstart=true&machine=basicLinux32gb&repo=CheirZ/HuTao-Proyect&ref=main&geo=UsEast)

#### ⚡ ACRIVAR EN REPLIT
[![`CREAR SERVIDOR REPLIT`](https://repl.it/badge/github/CheirZ/HuTao-Proyect)](https://repl.it/github/CheirZ/HuTao-Proyect)

#### 🤍 ACTIVAR EN RENDER
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%CheirZ%HuTao-Proyect) 

## <img src="https://static.wikia.nocookie.net/nyancat/images/d/d3/Nyan-cat.gif/revision/latest/scale-to-width-down/400?cb=20131231222500&path-prefix=es" alt="Grupo" width="45" height="43"> Bot Oficial ☄️

<a href="https://wa.me/5216566753569?text=!menu"><img alt="Bot Oficial ☄️" src="https://img.shields.io/badge/Bot - Oficial-00FFFF?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

> No Spam Al  Bot! (solo esta disponible para grupos)

---

## <img src="https://i.pinimg.com/originals/73/69/6e/73696e022df7cd5cb3d999c6875361dd.gif" alt="Características" width="42" height="42"> Características

> Bot en creación pronto se agregaran más cosas 

- [x] Interacción con voz y texto
- [x] Configuración de grupo
- [x] antidelete, antilink, antispam, etc
- [x] Bienvenida personalizada
- [x] Juegos, tictactoe, mate, etc
- [x] Chatbot (simsimi)
- [ ] Chatbot (modoia)
- [x] Crear sticker de image/video/gif/url
- [ ] Buscador Google
- [x] Juego RPG
- [ ] Personalizar imagen del menú
- [x] Descarga de música y video De YT
- [ ] Otros

--- 


### **`🦋 COLABORADORES`**
<a href="https://github.com/CheirZ/Hutao-Proyect/graphs/contributors">
<img src="https://contrib.rocks/image?repo=CheirZ/Hutao-Proyect" /> 
</a>

### **`❤️‍🔥 PROPIETARIO`**
<a
href="https://github.com/CheirZ"><img src="https://github.com/CheirZ.png" width="130" height="130" alt="Miguelon"/></a>

> Copyright (c) 2024 **[Xi_Miguelon](https://whatsapp.com/channel/0029VacDy0R6hENqnTKnG820)**.

**`¡GRACIAS POR PREFERIRNOS!` 🔥**
